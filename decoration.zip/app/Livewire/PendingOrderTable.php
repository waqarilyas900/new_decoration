<?php

namespace App\Livewire;

use Livewire\Component;

class PendingOrderTable extends Component
{
    public function render()
    {
        return view('livewire.pending-order-table');
    }
}
